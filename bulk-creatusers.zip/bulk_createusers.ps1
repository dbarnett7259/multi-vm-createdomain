﻿$FirstNames = Get-Content C:\temp\Names\FirstName.csv

$LastNames = Get-Content C:\temp\Names\LastName.csv

Import-Module activedirectory
$UsersToCreate = read-host "How many mailboxes do you want to create?  Default is 1000"
if ($UsersToCreate -eq ""){$UsersToCreate = 1000}
$Password = ConvertTo-SecureString "pass@word1" -AsPlainText -Force

$domainname = Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem | Select Domain

New-ADOrganizationalUnit -Name "$($domainname.domain)/testusers" -ErrorAction SilentlyContinue | Out-Null

$OU = "$($domainname.domain)/testusers"

$Departments = "Finance","IT","Marketing","Engineering","Sales","Human Resources"

$UPNSuffix = "$($domainname.domain)"

foreach ($Department in $Departments)

{

    New-DistributionGroup -Name $Department -OrganizationalUnit $OU -ErrorAction SilentlyContinue | Out-Null

}

for ($i=0; $i -lt $UsersToCreate; $i++)

{

    $FirstName = $FirstNames[(Get-Random -Minimum 0 -Maximum ($FirstNames.Count-1))]

    $LastName = $LastNames[(Get-Random -Minimum 0 -Maximum ($LastNames.Count-1))]

    $Username = "$($Firstname).$($LastName)"

    $DisplayName = "$($Firstname) $($LastName)"

    $Department = $Departments[(Get-Random -Minimum 0 -Maximum ($Departments.Count-1))]

    New-Mailbox -Name $DisplayName -SamAccountName $Username -UserPrincipalName "$($Username)@$($UPNSuffix)" -Alias $Username  -OrganizationalUnit $OU -Password $Password -FirstName $FirstName -LastName $LastName | out-null
    "$($Username)@$($UPNSuffix) mailbox created successfully"
    
    Set-User -Identity $Username -Department $Department | Out-Null
    "$($Username)@$($UPNSuffix) attributes updated successfully"

    Add-DistributionGroupMember -Identity $Department -Member $Username | Out-Null
    "$($Username)@$($UPNSuffix) Addded to Distribution List successfully"
}
Write-Host -ForegroundColor Green "$($UsersToCreate) mailboxes have been created for use!"